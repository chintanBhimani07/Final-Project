-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2023 at 11:49 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php-master`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` text NOT NULL,
  `client_first_name` varchar(100) NOT NULL,
  `client_last_name` varchar(100) NOT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `client_address` varchar(100) DEFAULT NULL,
  `client_email` varchar(100) NOT NULL,
  `client_contact` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` text NOT NULL,
  `emp_first_name` varchar(100) NOT NULL,
  `emp_last_name` varchar(100) NOT NULL,
  `emp_code` bigint(20) NOT NULL,
  `emp_description` text DEFAULT NULL,
  `emp_gender` varchar(10) NOT NULL,
  `emp_dob` date NOT NULL,
  `emp_mob` bigint(20) NOT NULL,
  `emp_email` varchar(100) NOT NULL,
  `emp_address` text DEFAULT NULL,
  `emp_department` varchar(100) NOT NULL,
  `emp_designation` varchar(100) NOT NULL,
  `emp_hod_name` varchar(100) NOT NULL,
  `emp_joining_date` date NOT NULL,
  `emp_confirmation_date` date DEFAULT NULL,
  `emp_working_hours` time NOT NULL,
  `emp_profile_pic` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_first_name`, `emp_last_name`, `emp_code`, `emp_description`, `emp_gender`, `emp_dob`, `emp_mob`, `emp_email`, `emp_address`, `emp_department`, `emp_designation`, `emp_hod_name`, `emp_joining_date`, `emp_confirmation_date`, `emp_working_hours`, `emp_profile_pic`) VALUES
('49edfcb8f9494c45ac8e4586edbdcf3f', 'Pratiksha', 'Chopda', 2, 'I am working good in any post I get in company', 'Female', '2002-10-07', 8140410634, 'pari@gmail.com', '1101, Rivera Aliganza, near tapi river , mota varachcha, surat-395006, gujrat, india', 'Architecture', 'HOD', '', '2023-01-01', '0000-00-00', '08:00:00', '1680671760_1679987160_WhatsApp Image 2023-03-28 at 12.21.40.jpeg'),
('b9be2df87787489493a3ea037c0357d5', 'Jemin', 'Prajapati', 5, 'I am good Architecture', 'Male', '2000-12-01', 9638754123, 'jaimin@gmail.com', '', 'Interior', 'Intern', '', '2023-01-01', '2023-01-01', '08:00:00', NULL),
('e2209ee9482c4e60adf16a205c78eed6', 'Jasmin', 'Bhanderi', 3, 'I put my best in  job and increase company growth', 'Female', '2003-01-01', 8528527410, 'jasmin@gmail.com', '21, Radha Krushna Society,  Near Aashadeep Vidhyalaya, Varachha road, surat-395006,  gujrat, india', 'Architecture', 'Junior Architecture', 'Pratiksha Chopda', '2023-01-01', '2023-01-01', '08:00:00', '1680672180_1679986980_WhatsApp Image 2023-03-28 at 12.23.33.jpeg'),
('e38fc52da2d7441883f88795a42777ce', 'Chintan', 'Bhimani', 4, 'Accounting Customer Service Skills Decision-making Skills Interpersonal Skills Teamwork Skills Organizational Skills Writing Skills Communication (Oral And Written)', 'Male', '2003-03-31', 9638702741, 'chintanbhimani07@gmail.com', '601 - Angarak, Rajhans Swapan, Opp. D-mart, Sarthana Nature Park, Surat-395006, Gujrat, India', 'Admin', 'Administrator', '', '2023-01-01', '2023-01-01', '09:30:00', '1680682200_1679986560_WhatsApp Image 2023-03-28 at 12.21.56.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `exp_id` text NOT NULL,
  `exp_name` text NOT NULL,
  `exp_amount` double NOT NULL,
  `exp_date` date NOT NULL,
  `exp_bill_photo` text NOT NULL,
  `exp_createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE `hod` (
  `hod_id` text NOT NULL,
  `hod_first_name` text NOT NULL,
  `hod_last_name` text NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `emp_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`hod_id`, `hod_first_name`, `hod_last_name`, `department_name`, `emp_id`) VALUES
('097d5b0c6aab446cb2e315295077c00b', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f'),
('113ae334d5ed4a0da86b81f5d35f0c73', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f'),
('51d925f65793449daff0d72c38fc3782', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f'),
('8f1574da1cbb4a549b19f72123bcb70e', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f'),
('b78a0f90e9aa43bdb94ac956455fbbce', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f'),
('e62bb612d683451e9b87110a6b40952d', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f'),
('f4d740ea64414e7caba221cf700995d8', 'Pratiksha', 'Chopda', 'Architecture', '49edfcb8f9494c45ac8e4586edbdcf3f');

-- --------------------------------------------------------

--
-- Table structure for table `lead`
--

CREATE TABLE `lead` (
  `lead_id` text NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_email` varchar(255) NOT NULL,
  `client_tel_no` int(100) NOT NULL,
  `project_type` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `lead_status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `leave_id` text NOT NULL,
  `leave_type` varchar(255) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `posting_date` varchar(255) NOT NULL,
  `admin_remarks` varchar(255) DEFAULT NULL,
  `admin_remarks_date` varchar(255) DEFAULT NULL,
  `leave_status` int(10) NOT NULL,
  `is_read` int(10) NOT NULL,
  `user_id` text NOT NULL,
  `leave_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leavestype`
--

CREATE TABLE `leavestype` (
  `leave_type_id` text NOT NULL,
  `leave_type` varchar(255) NOT NULL,
  `leave_description` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otplogs`
--

CREATE TABLE `otplogs` (
  `otp_id` text NOT NULL,
  `otp_email` varchar(255) NOT NULL,
  `otp` int(10) NOT NULL,
  `send_At` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `productivity`
--

CREATE TABLE `productivity` (
  `productivity_id` text NOT NULL,
  `project_id` text NOT NULL,
  `task_id` text NOT NULL,
  `productivity_comments` text NOT NULL,
  `productivity_subject` varchar(255) NOT NULL,
  `productivity_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `user_id` text NOT NULL,
  `time_rendered` float NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `project_id` text NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_code` varchar(100) NOT NULL,
  `client_id` text NOT NULL,
  `start_date` date NOT NULL,
  `expected_end_date` date DEFAULT NULL,
  `hod_id` text NOT NULL,
  `nature_of_project` varchar(100) NOT NULL,
  `reference_by` text DEFAULT NULL,
  `project_location` varchar(100) NOT NULL,
  `engineers_id` text DEFAULT NULL,
  `users_id` text DEFAULT NULL,
  `project_status` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `task_id` text NOT NULL,
  `project_id` text NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `task_description` text NOT NULL,
  `task_assign_from` text NOT NULL,
  `task_assign_to` varchar(255) NOT NULL,
  `task_status` int(10) NOT NULL COMMENT '0: Pending,\r\n1: On Progress,\r\n2: Complete,\r\n3: Hold',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` text NOT NULL,
  `user_email` text NOT NULL,
  `user_password` text NOT NULL,
  `emp_id` text NOT NULL,
  `user_first_name` varchar(100) NOT NULL,
  `user_last_name` varchar(100) NOT NULL,
  `user_access_type` int(10) NOT NULL DEFAULT 3 COMMENT '1: Admin\r\n2: HOD\r\n3: Employee'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `user_password`, `emp_id`, `user_first_name`, `user_last_name`, `user_access_type`) VALUES
('411dd037be9844aab996e3affeac020c', 'pari@gmail.com', '3b8100eceabeea4260608eb62a48eaac', '49edfcb8f9494c45ac8e4586edbdcf3f', 'Pratiksha', 'Chopda', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`(255));

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`(255));

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`exp_id`(255));

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
  ADD PRIMARY KEY (`hod_id`(255));

--
-- Indexes for table `lead`
--
ALTER TABLE `lead`
  ADD PRIMARY KEY (`lead_id`(255));

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`leave_id`(255));

--
-- Indexes for table `leavestype`
--
ALTER TABLE `leavestype`
  ADD PRIMARY KEY (`leave_type_id`(255));

--
-- Indexes for table `otplogs`
--
ALTER TABLE `otplogs`
  ADD PRIMARY KEY (`otp_id`(255));

--
-- Indexes for table `productivity`
--
ALTER TABLE `productivity`
  ADD PRIMARY KEY (`productivity_id`(255));

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`(255));

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`(255));

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`(255));
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
