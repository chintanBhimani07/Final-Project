let data = [
  {
    id: 118,
    created_at: "2023-02-28T09:40:07.000000Z",
    updated_at: "2023-02-28T09:40:07.000000Z",
    mom_id: "86309d5d335749eb96683ff442aa1c1c",
    user_id: "0ee3ec9ce04a4a92bd95a78c075953a0",
    with_punch_in_detail: {
      created_at: "2023-02-28T09:25:08.000000Z",
      mom_id: "86309d5d335749eb96683ff442aa1c1c",
      user_id: "0ee3ec9ce04a4a92bd95a78c075953a0",
      project_code: "b0c8aefb18904c0f8c6e4875b50befb1",
      with_project_detail: null,
      with_place_detail: {
        id: 13,
        created_at: "2022-10-05T09:55:34.000000Z",
        updated_at: "2022-10-05T09:55:34.000000Z",
        place_id: "b0c8aefb18904c0f8c6e4875b50befb1",
        place_name: "Shreeji Ceramics",
        place_category: "Selection Store",
        phone: null,
        email: null,
        is_deleted: 0,
      },
      with_user_details: {
        id: 18,
        created_at: "2022-09-17T06:34:16.000000Z",
        updated_at: "2023-03-04T10:06:53.000000Z",
        user_id: "0ee3ec9ce04a4a92bd95a78c075953a0",
        user_first_name: "Testing",
        user_last_name: "User",
        user_phone_number: "1234567890",
        user_mail_id: "sapaved109@geekjun.com",
        user_department: "Designer",
        is_active: "1",
        cosec_id: 0,
        user_designation: "HOD",
        user_hod: null,
      },
      with_hod_notes: [],
    },
    with_drawing_requirement: [
      {
        id: 125,
        created_at: "2023-02-28T09:40:07.000000Z",
        updated_at: "2023-03-05T20:20:51.000000Z",
        mom_id: "86309d5d335749eb96683ff442aa1c1c",
        area_id: "36c23c6141a44af4b29675f0a1cf9029",
        mom_drawing_req_id: "c893ee37e02449bc840c72f84d63798a",
        task: "concept",
        completion_date: "2023-03-05",
        notes: "test1",
        status: "complete",
        with_area_detail: {
          area_id: "36c23c6141a44af4b29675f0a1cf9029",
            area_name: "Badminton_Court",
        },
      },
      {
        id: 126,
        created_at: "2023-02-28T09:40:07.000000Z",
        updated_at: "2023-03-05T20:21:06.000000Z",
        mom_id: "86309d5d335749eb96683ff442aa1c1c",
        area_id: "a91312eb974c42488c2c9e29be900a3f",
        mom_drawing_req_id: "c029bc9ded074e72b19625eb3e49b580",
        task: "ghfgh",
        completion_date: "2023-03-11",
        notes: "test3",
        status: "inprogress",
        with_area_detail: {
          area_id: "a91312eb974c42488c2c9e29be900a3f",
          area_name: "Kid_Bedroom",
        },
      },
    ],
  },
];

let newArray = [];

data.forEach((obj) => {
  obj.with_drawing_requirement.forEach((d) => {
    newArray.push({
      momId: obj.mom_id,
      drawingReqId: d.mom_drawing_req_id,
      projectName: (obj.with_punch_in_detail.with_project_detail != null ? `${obj.with_punch_in_detail.with_project_detail.project_name}, ${obj.with_punch_in_detail.with_project_detail.client_name}` : null),
      placeName: (obj.with_punch_in_detail.with_place_detail != null ? `${obj.with_punch_in_detail.with_place_detail.place_name}, ${obj.with_punch_in_detail.with_place_detail.place_category}` : null),
      area: d.with_area_detail.area_name,
      task: d.task,
      completionDate: d.completion_date,
      notes: d.notes,
      status: d.status,
    });
  });
});

console.log(newArray);

