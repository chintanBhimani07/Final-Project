<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Projects Report</h1>
        <a href="./index.php?page=project-dashboard" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white mr-2"></i>All Projects</a>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Project List</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Sr No.</th>
                                    <th>Project</th>
                                    <th>No. Of Task</th>
                                    <th>Completed Task</th>
                                    <th>Work Duration</th>
                                    <th>Progress</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                $stat = array("Pending", "Started", "On-Progress", "On-Hold", "Over Due", "Done");
                                $qry = $con->query("SELECT * FROM  projects;");
                                while ($row = $qry->fetch_assoc()) {
                                    $projectId = $row['project_id'];
                                    $totalTask = $con->query("SELECT * FROM task where project_id='$projectId'")->num_rows;
                                    $completeTask = $con->query("SELECT * FROM task where project_id ='$projectId' and task_status = 3")->num_rows;
                                    $progress = $totalTask > 0 ? ($completeTask / $totalTask) * 100 : 0;
                                    $progress = $progress > 0 ? number_format($progress, 2) : $progress;
                                ?>
                                    <tr>
                                        <th scope="row">
                                            <?php echo $i++ ?>
                                        </th>
                                        <td>
                                            <?php echo $row['project_name'] ?>
                                            <small style="display:block;">
                                                Due: <?php echo date("Y-m-d", strtotime($row['expected_end_date'])) ?>
                                            </small>
                                        </td>
                                        <td>
                                        <?php echo number_format($totalTask) ?>
                                        </td>
                                        <td>
                                        <?php echo number_format($completeTask) ?>
                                        </td>
                                        <td>
                                            <?php echo $row['start_date'] ?>
                                        </td>
                                        <td>
                                            <?php echo $row['expected_end_date'] ?>
                                        </td>
                                        <td>
                                            <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar w-75"></div>
                                            </div>
                                            <small>
                                                <?php echo $prprogressog ?>% Complete
                                            </small>
                                        </td>
                                        <td class="d-flex align-items-center justify-content-center">
                                            <a type="button" class="btn btn-primary btn-circle mx-1" href="./index.php?page=project-viewer&projectId=<?php echo $row['project_id'] ?>"><i class="fa-solid fa-eye"></i></a>
                                            <a type="button" class="btn btn-warning  btn-circle mx-1" href="./index.php?page=project-edit&projectId=<?php echo $row['project_id'] ?>"><i class="fa-solid fa-user-pen"></i></a>
                                            <a type="button" class="btn btn-danger  btn-circle deleteProject  mx-1" href="#" data-id="<?php echo $row['project_id'] ?>"><i class="fa-solid fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        $('.deleteProject').click(function() {
            // console.log('click');
            let id = $(this).attr('id');
            $.ajax({
                url: './php/actions.php?action=delete_project',
                method: 'POST',
                data: {
                    project_id: id
                },
                success: function(resp) {
                    if (resp == 1) {
                        setTimeout(function() {
                            location.reload()
                        }, 1000)

                    } else {
                        console.log(resp);
                    }
                }
            });
        });
    });
</script>