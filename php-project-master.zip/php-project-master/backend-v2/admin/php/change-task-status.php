<?php

include '../config/db.config.php';
// Get the record ID from the query string
$id = $_GET['id'];
$qry = $con->query("UPDATE task SET task_status=1 WHERE task_id='$id'");

if($qry){
    header('Location: ../work-collector.php');
}
// Redirect back to the page with the table
exit;
?>